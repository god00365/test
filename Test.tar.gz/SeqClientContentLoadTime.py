import urllib2
import time
from datetime import datetime

proxy_support = urllib2.ProxyHandler({"http" : "155.98.39.24:3128"})
opener = urllib2.build_opener(proxy_support) 

text = open("SeqClientContentLoadTime.txt",'a')

for i in range(0, 50):
    #print "case "+str(i+1)
    order = "case " + str(i+1)
    text.write(order)
   
    proxy_support = urllib2.ProxyHandler({"http" : "155.98.39.24:3128"})
    urllib2.install_opener(opener)
    request = urllib2.Request("http://en.wikipedia.org/")
    request.add_header('Pragma','no-cache')
    start = time.time()

    content = urllib2.build_opener().open(request)
    end = time.time()
    result = end - start
    now = datetime.now()
    text.write("\n%s   %s\n" % (result,now))
